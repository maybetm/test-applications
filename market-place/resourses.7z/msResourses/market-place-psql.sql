--
-- PostgreSQL database cluster dump
--

-- Started on 2018-10-22 00:34:23

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin;
ALTER ROLE admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION NOBYPASSRLS PASSWORD 'md5f6fdffe48c908deb0f4c3bd36c032e72' VALID UNTIL 'infinity';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md53175bce1d3201d16594cebf9d7eb3f9d';






--
-- Database creation
--

CREATE DATABASE "market-place-db" WITH TEMPLATE = template0 OWNER = postgres;
GRANT CONNECT,TEMPORARY ON DATABASE "market-place-db" TO pg_signal_backend;
REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


\connect -reuse-previous=on "dbname='market-place-db'"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

-- Started on 2018-10-22 00:34:23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12278)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2225 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 221 (class 1255 OID 16653)
-- Name: topay(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.topay(usrid integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE
	cartCount Integer;
 BEGIN    
 
 update goods set count = goods.count - data_table.count
from
(select unnest(array (SELECT  goods.id FROM   public.cart,  public.goods,  public.category,  public.users
			WHERE 
			  cart.userid = usrid AND
			  cart.goodsid = goods.id AND
			  users.id = cart.userid AND 
			  category.id = goods.categoryid)) as id, 

        unnest(array(SELECT  cart.count FROM   public.cart,  public.goods,  public.category,  public.users
			WHERE 
			  cart.userid = usrid AND
			  cart.goodsid = goods.id AND
			  users.id = cart.userid AND 
			  category.id = goods.categoryid)) as count) as data_table
where goods.id = data_table.id;

insert into statistics
(username, gname, gcategory, ginfo, ccount, gprice,  totalsumposition, datetopay, marketID)
SELECT 
  users.email, goods.name as gname, category.name as cName, goods.info as ginfo,
  cart.count as cCount, goods.price as priceOne, (goods.price * cart.count) as sumItems, (select now() ),
  goods.marketid
  
FROM 
  public.cart, public.goods,  public.category, public.users
WHERE 
  cart.userid = usrid AND cart.goodsid = goods.id AND users.id = cart.userid AND category.id = goods.categoryid;

  cartCount = (select count(*) from cart where userid = usrid);

  delete from cart where userid = usrid;
   		
  return cartCount;
END; $$;


ALTER FUNCTION public.topay(usrid integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 204 (class 1259 OID 16571)
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    id integer NOT NULL,
    userid integer,
    goodsid integer,
    count integer
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- TOC entry 203 (class 1259 OID 16569)
-- Name: cart_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cart_id_seq OWNER TO postgres;

--
-- TOC entry 2226 (class 0 OID 0)
-- Dependencies: 203
-- Name: cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cart_id_seq OWNED BY public.cart.id;


--
-- TOC entry 202 (class 1259 OID 16541)
-- Name: category; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.category (
    id integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.category OWNER TO admin;

--
-- TOC entry 201 (class 1259 OID 16539)
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_seq OWNER TO admin;

--
-- TOC entry 2227 (class 0 OID 0)
-- Dependencies: 201
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.category_id_seq OWNED BY public.category.id;


--
-- TOC entry 200 (class 1259 OID 16522)
-- Name: goods; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.goods (
    id integer NOT NULL,
    marketid integer,
    name character varying(35),
    info text,
    categoryid integer,
    count integer,
    price numeric,
    logo text
);


ALTER TABLE public.goods OWNER TO admin;

--
-- TOC entry 199 (class 1259 OID 16520)
-- Name: goods_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.goods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.goods_id_seq OWNER TO admin;

--
-- TOC entry 2228 (class 0 OID 0)
-- Dependencies: 199
-- Name: goods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.goods_id_seq OWNED BY public.goods.id;


--
-- TOC entry 198 (class 1259 OID 16493)
-- Name: roles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.roles (
    id integer,
    namerole character varying(10)
);


ALTER TABLE public.roles OWNER TO admin;

--
-- TOC entry 206 (class 1259 OID 16656)
-- Name: statistics; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.statistics (
    id integer NOT NULL,
    username text,
    gname text,
    gcategory text,
    ginfo text,
    ccount integer,
    gprice numeric,
    totalsumposition numeric,
    marketid integer,
    datetopay timestamp with time zone
);


ALTER TABLE public.statistics OWNER TO admin;

--
-- TOC entry 205 (class 1259 OID 16654)
-- Name: statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.statistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statistics_id_seq OWNER TO admin;

--
-- TOC entry 2229 (class 0 OID 0)
-- Dependencies: 205
-- Name: statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.statistics_id_seq OWNED BY public.statistics.id;


--
-- TOC entry 208 (class 1259 OID 16685)
-- Name: timezones; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.timezones (
    id integer NOT NULL,
    name text,
    offsetutc text,
    info text
);


ALTER TABLE public.timezones OWNER TO admin;

--
-- TOC entry 207 (class 1259 OID 16683)
-- Name: timezones_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.timezones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.timezones_id_seq OWNER TO admin;

--
-- TOC entry 2230 (class 0 OID 0)
-- Dependencies: 207
-- Name: timezones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.timezones_id_seq OWNED BY public.timezones.id;


--
-- TOC entry 197 (class 1259 OID 16469)
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(50),
    email character varying(255),
    password character varying(45),
    roleid integer,
    timeset text DEFAULT 'UTC-3'::text NOT NULL
);


ALTER TABLE public.users OWNER TO admin;

--
-- TOC entry 196 (class 1259 OID 16467)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO admin;

--
-- TOC entry 2231 (class 0 OID 0)
-- Dependencies: 196
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 2067 (class 2604 OID 16574)
-- Name: cart id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart ALTER COLUMN id SET DEFAULT nextval('public.cart_id_seq'::regclass);


--
-- TOC entry 2066 (class 2604 OID 16544)
-- Name: category id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.category ALTER COLUMN id SET DEFAULT nextval('public.category_id_seq'::regclass);


--
-- TOC entry 2065 (class 2604 OID 16525)
-- Name: goods id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.goods ALTER COLUMN id SET DEFAULT nextval('public.goods_id_seq'::regclass);


--
-- TOC entry 2068 (class 2604 OID 16659)
-- Name: statistics id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.statistics ALTER COLUMN id SET DEFAULT nextval('public.statistics_id_seq'::regclass);


--
-- TOC entry 2069 (class 2604 OID 16688)
-- Name: timezones id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.timezones ALTER COLUMN id SET DEFAULT nextval('public.timezones_id_seq'::regclass);


--
-- TOC entry 2063 (class 2604 OID 16472)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 2213 (class 0 OID 16571)
-- Dependencies: 204
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (id, userid, goodsid, count) FROM stdin;
113	1	60	1
114	1	62	1
115	1	63	1
12	7	12	1
13	7	14	1
11	7	9	8
15	7	110	1
16	8	12	1
17	8	14	12
\.


--
-- TOC entry 2211 (class 0 OID 16541)
-- Dependencies: 202
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.category (id, name) FROM stdin;
1	Одежда и обувь
2	Аксессура и украшения
3	Дом и сад
4	Авто-, мото
5	Техника и электроника
6	Материалы для ремонта
7	Товары для детей
8	Красота и здоровье
9	Спорт и отдых
10	Продукты питания
11	Подарки, хобби, книги
12	Инструмент
13	Другое
\.


--
-- TOC entry 2209 (class 0 OID 16522)
-- Dependencies: 200
-- Data for Name: goods; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.goods (id, marketid, name, info, categoryid, count, price, logo) FROM stdin;
132	3	test	 tesdt	3	1	23	1452003297175654281.jpg
133	3	tettt	 tetet	2	0	123	407954-4-f.jpg
85	3	Тестовый товарТестовый товар	 Тестовый товарТестовый товар	5	18	3334.00	5085a84eaeUABFODF_38471_0ddb81eea8.gif
83	5	Тестовый товарТестовый товар	 Тестовый товарТестовый товар	8	-110	3232.00	b5c42097-b3ec-47fb-89e7-26c58ef57c90БЛА2.JPG
97	3	аниме	 weqeqw	1	-214	123.00	2bf740daf4ba.gif
76	5	Прекрасный мем	Не очень длинное описание, не очень хорошего мема. 	13	20	331.12	1jI5GYNVPFU.jpg
82	5	Тестовый товар	 Тестовый товар	5	20	2323.00	YzraqmuSmXU.jpg
72	3	se	 esse2	3	18	3123.00	YzraqmuSmXU.jpg
79	5	Тестовый товар	ТестовыйТестовый товартовар	3	-1	3333.00	767dae38-4c8f-4df8-a9b4-3725e89fb625av-3913.gif
134	3	test	 tetetete	9	231	321	1jI5GYNVPFU.jpg
71	3	12	 123	1	17	132.00	YzraqmuSmXU.jpg
65	3	123123	 123	1	13	123.00	YzraqmuSmXU.jpg
64	3	212	 3123	1	12	3.00	YzraqmuSmXU.jpg
63	3	123123123	 123	1	11	123.00	YzraqmuSmXU.jpg
60	3	Мало очень	 	1	1	123.00	YzraqmuSmXU.jpg
62	3	123123123	 123	1	2	123.00	YzraqmuSmXU.jpg
77	5	Картинка	Продам картинку 	13	20	999.12	dd90c60d-2565-4bef-ba3f-2ea122d26eab957fc43b89b3.jpg
101	3	123	 123	1	20	123.00	5ca8e00aac48.jpg
103	3	testtt	 23123123	7	20	312.00	45f62457e66a.jpg
111	5	33333	 3	1	20	3	1442228382110371245.jpg
61	3	123123123	 123	1	0	123.00	YzraqmuSmXU.jpg
78	5	тест	 тест	2	19	33.00	81a5f6ce-fc28-4823-ba37-3b57ade9a3d11442228382110371245.jpg
96	3	15:03	 213	1	19	123.00	fbdbff04-4388-4ad6-a465-52d0489fa09d128.png
80	5	Тестовый МЕМ	 Тестовый товар	6	19	333.00	821e6018-ee91-4126-9d7a-4acda22d6119i.jpg
66	3	123123	 123	1	0	123.00	YzraqmuSmXU.jpg
70	3	12	 123	1	19	132.00	YzraqmuSmXU.jpg
73	3	3333333	 333333333	1	20	323.00	YzraqmuSmXU.jpg
74	3	33333333334	 123	1	20	123.00	YzraqmuSmXU.jpg
99	3	Уточка	Мем с уточкой	1	20	6543.00	24c30e7b-88fe-4a50-925e-4763ea335543i.jpg
109	3	31231	 213213	7	20	123	4_04_07_2016.jpg
110	3	еуые	еуые 	1	20	231	5085a84eaeUABFODF_38471_0ddb81eea8.gif
84	5	Тестовый товарТестовый товар	 Тестовый товарТестовый товар	7	19	23123.00	0848e65e-4caa-4fb3-928a-6d8714f844f4496812.jpg
126	3	123	 123	2	19	213	5085a84eaeUABFODF_38471_0ddb81eea8.gif
120	3	Тестовый товарТестовый товар 8	 Тестовый товарТестовый товар 8	3	19	32	YzraqmuSmXU.jpg
129	3	213	 213	1	19	213	f09b9279b6aaca5e44cddd5f9372b397.jpg
131	3	12	 12	1	19	231	7eMBoTj-K8g.jpg
87	5	3333333	 333333333333333333333	11	17	4444.00	0156de44-a7fe-48a8-8893-35866c3bde5f14236907991492.gif
135	3	testttttttt	 test	1	9999	99	загружено.jpg
136	3	Товар для теста	Забыл где лежит скрытая папка сервера приложений на окошках	13	123	33	1jI5GYNVPFU.jpg
113	3	Тестовый товарТестовый товар	 Тестовый товарТестовый товар	1	20	123	YzraqmuSmXU.jpg
114	3	Тестовый товарТестовый товар 2	 Тестовый товарТестовый товар 2	1	20	123123	YzraqmuSmXU.jpg
115	3	Тестовый товарТестовый товар 3	 Тестовый товарТестовый товар 3	1	20	32.42	YzraqmuSmXU.jpg
116	3	Тестовый товарТестовый товар 4	Тестовый товарТестовый товар 4 ds	1	20	33.42	YzraqmuSmXU.jpg
98	3	Нормальное название	Нормальное описание	1	20	31231.00	4_04_07_2016.jpg
112	3	213213213	 213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213 213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213 213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213213	2	20	213	496812.jpg
117	3	Тестовый товарТестовый товар 5	 Тестовый товарТестовый товар 5	9	20	32	YzraqmuSmXU.jpg
118	3	Тестовый товарТестовый товар 6	 Тестовый товарТестовый товар 6	1	20	41	YzraqmuSmXU.jpg
119	3	Тестовый товарТестовый товар 7	 Тестовый товарТестовый товар 7	1	20	32.12	YzraqmuSmXU.jpg
121	3	Тестовый товарТестовый товар 9	 Тестовый товарТестовый товар 9	5	20	32	YzraqmuSmXU.jpg
122	3	Тестовый товарТестовый товар 10	 Тестовый товарТестовый товар 10	1	20	32	YzraqmuSmXU.jpg
123	3	Тестовый товарТестовый товар 11	 Тестовый товарТестовый товар 11	1	20	23.12	YzraqmuSmXU.jpg
124	3	Тестовый товарТестовый товар 12	 Тестовый товарТестовый товар 11	1	20	21	YzraqmuSmXU.jpg
128	3	123	 213	4	20	321	407954-4-f.jpg
\.


--
-- TOC entry 2207 (class 0 OID 16493)
-- Dependencies: 198
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.roles (id, namerole) FROM stdin;
1	user
2	market
\.


--
-- TOC entry 2215 (class 0 OID 16656)
-- Dependencies: 206
-- Data for Name: statistics; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.statistics (id, username, gname, gcategory, ginfo, ccount, gprice, totalsumposition, marketid, datetopay) FROM stdin;
1	sergey2907@mail.com	Тестовый товар	Дом и сад	ТестовыйТестовый товартовар	19	3333.00	63327.00	5	2018-10-20 12:49:13.889613+00
2	sergey2907@mail.com	123123123	Одежда и обувь	 123	3	123.00	369.00	3	2018-10-20 12:49:13.889613+00
3	sergey2907@mail.com	212	Одежда и обувь	 3123	3	3.00	9.00	3	2018-10-20 12:49:13.889613+00
4	sergey2907@mail.com	123123	Одежда и обувь	 123	3	123.00	369.00	3	2018-10-20 12:49:13.889613+00
5	sergey2907@mail.com	123123	Одежда и обувь	 123	20	123.00	2460.00	3	2018-10-20 12:49:13.889613+00
6	sergey2907@mail.com	12	Одежда и обувь	 123	1	132.00	132.00	3	2018-10-20 13:06:49.005194+00
7	sergey2907@mail.com	123123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-20 13:06:49.005194+00
8	sergey2907@mail.com	123123	Одежда и обувь	 123	2	123.00	246.00	3	2018-10-20 13:06:49.005194+00
9	sergey2907@mail.com	12	Одежда и обувь	 123	1	132.00	132.00	3	2018-10-20 13:06:49.005194+00
10	sergey2907@mail.com	212	Одежда и обувь	 3123	1	3.00	3.00	3	2018-10-20 13:07:34.207732+00
11	sergey2907@mail.com	123123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-20 13:07:34.207732+00
12	sergey2907@mail.com	123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-20 13:07:34.207732+00
13	sergey2907@mail.com	212	Одежда и обувь	 3123	1	3.00	3.00	3	2018-10-20 13:42:55.879257+00
14	sergey2907@mail.com	123123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-20 13:42:55.879257+00
15	sergey2907@mail.com	212	Одежда и обувь	 3123	1	3.00	3.00	3	2018-10-20 13:44:31.231273+00
16	sergey2907@mail.com	123123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-20 13:44:31.231273+00
17	sergey2907@mail.com	3333333	Подарки, хобби, книги	 333333333333333333333	3	4444.00	13332.00	5	2018-10-20 13:44:31.231273+00
18	sergey2907@mail.com	212	Одежда и обувь	 3123	1	3.00	3.00	3	2018-10-20 13:46:52.053373+00
19	sergey2907@mail.com	123123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-20 13:46:52.053373+00
20	sergey2907@mail.com	tettt	Аксессура и украшения	 tetet	31	123	3813	3	2018-10-20 14:03:18.006297+00
21	sergeysergey	Тестовый товарТестовый товар	Техника и электроника	 Тестовый товарТестовый товар	2	3334.00	6668.00	3	2018-10-20 21:33:14.801299+00
22	sergeysergey	se	Дом и сад	 esse2	1	3123.00	3123.00	3	2018-10-20 21:33:14.801299+00
23	sergeysergey	Тестовый товар	Дом и сад	ТестовыйТестовый товартовар	1	3333.00	3333.00	5	2018-10-20 21:33:14.801299+00
24	sergey2907@mail.com	12	Одежда и обувь	 123	1	132.00	132.00	3	2018-10-21 12:11:36.362012+00
25	sergey2907@mail.com	123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-21 12:11:36.362012+00
26	sergey2907@mail.com	212	Одежда и обувь	 3123	1	3.00	3.00	3	2018-10-21 12:11:36.362012+00
27	sergey2907@mail.com	123123123	Одежда и обувь	 123	1	123.00	123.00	3	2018-10-21 12:11:36.362012+00
\.


--
-- TOC entry 2217 (class 0 OID 16685)
-- Dependencies: 208
-- Data for Name: timezones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.timezones (id, name, offsetutc, info) FROM stdin;
12	Калининградское время	UTC-2	Калининградская область
13	Московское время	UTC-3	Большая часть Европейской части России и вся Российская железная дорога
14	Самарское время	UTC-4	Удмуртская Республика, Астраханская область, Самарская область, Саратовская область и Ульяновская область
15	Екатеринбургское время	UTC-5	Башкортостан, Челябинская область, Ханты-Мансийский автономный округ — Югра, Курганская область, Оренбургская область, Пермский край, Свердловская область, Тюменская область, Ямало-Ненецкий автономный округ
16	Омское время	UTC-6	Омская область
17	Красноярское время	UTC-7	Алтайский край, Республика Алтай, Новосибирская область, Хакасия, Красноярский край, Тыва, Кемеровская область, Томская область
18	Иркутское время	UTC-8	Бурятия и Иркутская область
19	Якутское время	UTC-9	Амурская область, западная часть Якутии и Забайкальский край 
20	Владивостокское время	UTC-10	Еврейская автономная область, Магаданская область, Хабаровский край, Приморский край
21	Среднеколымское время	UTC-11	центр и восток Якутии, остров Сахалин, Курильские острова
22	Камчатское время	UTC-12	Чукотский автономный округ и Камчатский край
\.


--
-- TOC entry 2206 (class 0 OID 16469)
-- Dependencies: 197
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (id, login, email, password, roleid, timeset) FROM stdin;
1	sergey	sergey2907@mail.com	bb4889c28f66e852b040127a92407e09	1	UTC-3
4	sergeyMarget	sergeymarget@gmail.com	7c87f586e37dbbd6d27d330edc3b9d9a	2	UTC-3
5	sergey29	sergey29@gmail.com	458ea5370a417f61adcf847ba6a86e00	2	UTC-3
7	sergey290796@mail.com	sergey290796@mail.com	30228112d0a25bd5f885efafc4f41b1f	1	UTC-3
8	sergey290796@gmail.com	sergey290796@gmail.com	160d112391d390e193018f73d7d13b78	1	UTC-3
9	sergey	sergeysergey	f1de6195ea0fd5b9afb2259ee005b255	1	UTC-3
10	test	test	098f6bcd4621d373cade4e832627b4f6	2	UTC-3
3	sergey	sergey2907@gmail.com	1f9ee606d8c6140241a5149f8489783f	2	UTC-3
\.


--
-- TOC entry 2232 (class 0 OID 0)
-- Dependencies: 203
-- Name: cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_id_seq', 115, true);


--
-- TOC entry 2233 (class 0 OID 0)
-- Dependencies: 201
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.category_id_seq', 13, true);


--
-- TOC entry 2234 (class 0 OID 0)
-- Dependencies: 199
-- Name: goods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.goods_id_seq', 136, true);


--
-- TOC entry 2235 (class 0 OID 0)
-- Dependencies: 205
-- Name: statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.statistics_id_seq', 27, true);


--
-- TOC entry 2236 (class 0 OID 0)
-- Dependencies: 207
-- Name: timezones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.timezones_id_seq', 22, true);


--
-- TOC entry 2237 (class 0 OID 0)
-- Dependencies: 196
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- TOC entry 2079 (class 2606 OID 16576)
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- TOC entry 2077 (class 2606 OID 16546)
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- TOC entry 2075 (class 2606 OID 16527)
-- Name: goods goods_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT goods_pkey PRIMARY KEY (id);


--
-- TOC entry 2081 (class 2606 OID 16664)
-- Name: statistics statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT statistics_pkey PRIMARY KEY (id);


--
-- TOC entry 2083 (class 2606 OID 16693)
-- Name: timezones timezones_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.timezones
    ADD CONSTRAINT timezones_pkey PRIMARY KEY (id);


--
-- TOC entry 2071 (class 2606 OID 16476)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 2073 (class 2606 OID 16474)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


-- Completed on 2018-10-22 00:34:23

--
-- PostgreSQL database dump complete
--

\connect postgres

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

-- Started on 2018-10-22 00:34:23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2145 (class 0 OID 0)
-- Dependencies: 2144
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 1 (class 3079 OID 12278)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2147 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


-- Completed on 2018-10-22 00:34:23

--
-- PostgreSQL database dump complete
--

\connect template1

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

-- Started on 2018-10-22 00:34:23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2145 (class 0 OID 0)
-- Dependencies: 2144
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- TOC entry 1 (class 3079 OID 12278)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2147 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


-- Completed on 2018-10-22 00:34:24

--
-- PostgreSQL database dump complete
--

-- Completed on 2018-10-22 00:34:24

--
-- PostgreSQL database cluster dump complete
--

